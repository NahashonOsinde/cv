/*
 * pilote_servo_origine.c
 *
 * Code generation for model "pilote_servo_origine".
 *
 * Model version              : 1.248
 * Simulink Coder version : 8.2 (R2012a) 29-Dec-2011
 * C source code generated on : Fri Nov 20 14:20:27 2020
 *
 * Target selection: rtwin.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#include "pilote_servo_origine.h"
#include "pilote_servo_origine_private.h"
#include "pilote_servo_origine_dt.h"

/* list of Real-Time Windows Target timers */
const int RTWinTimerCount = 1;
const double RTWinTimers[2] = {
  0.005, 0.0,
};

/* Block signals (auto storage) */
BlockIO_pilote_servo_origine pilote_servo_origine_B;

/* Block states (auto storage) */
D_Work_pilote_servo_origine pilote_servo_origine_DWork;

/* Real-time model */
RT_MODEL_pilote_servo_origine pilote_servo_origine_M_;
RT_MODEL_pilote_servo_origine *const pilote_servo_origine_M =
  &pilote_servo_origine_M_;

/* Model output function */
void pilote_servo_origine_output(void)
{
  /* Level2 S-Function Block: '<S2>/Encoder' (Servo_Encoder) */
  {
    SimStruct *rts = pilote_servo_origine_M->childSfunctions[0];
    sfcnOutputs(rts, 0);
  }

  /* Gain: '<S2>/Convert to rad' incorporates:
   *  Gain: '<S2>/Encoder 1024 PPR'
   */
  pilote_servo_origine_B.Converttorad[0] =
    pilote_servo_origine_P.Encoder1024PPR_Gain * pilote_servo_origine_B.Encoder
    [0] * pilote_servo_origine_P.Converttorad_Gain;
  pilote_servo_origine_B.Converttorad[1] =
    pilote_servo_origine_P.Encoder1024PPR_Gain * pilote_servo_origine_B.Encoder
    [1] * pilote_servo_origine_P.Converttorad_Gain;

  /* Level2 S-Function Block: '<S2>/RT-DAC Analog Inputs' (servo_analoginputs) */
  {
    SimStruct *rts = pilote_servo_origine_M->childSfunctions[1];
    sfcnOutputs(rts, 0);
  }

  /* Gain: '<S2>/Convert to rad//s' */
  pilote_servo_origine_B.Converttorads =
    pilote_servo_origine_P.Converttorads_Gain *
    pilote_servo_origine_B.RTDACAnalogInputs[0];

  /* Switch: '<S1>/SwitchControl' incorporates:
   *  Constant: '<Root>/Normal'
   *  Constant: '<Root>/Reset'
   *  Constant: '<S1>/Constant'
   */
  if (pilote_servo_origine_P.Constant_Value_c >
      pilote_servo_origine_P.SwitchControl_Threshold) {
    pilote_servo_origine_B.SwitchControl = pilote_servo_origine_P.Reset_Value;
  } else {
    pilote_servo_origine_B.SwitchControl = pilote_servo_origine_P.Normal_Value;
  }

  /* End of Switch: '<S1>/SwitchControl' */

  /* Saturate: '<S2>/Saturation' incorporates:
   *  Constant: '<Root>/Constant'
   */
  if (pilote_servo_origine_P.Constant_Value >=
      pilote_servo_origine_P.Saturation_UpperSat) {
    pilote_servo_origine_B.Saturation =
      pilote_servo_origine_P.Saturation_UpperSat;
  } else if (pilote_servo_origine_P.Constant_Value <=
             pilote_servo_origine_P.Saturation_LowerSat) {
    pilote_servo_origine_B.Saturation =
      pilote_servo_origine_P.Saturation_LowerSat;
  } else {
    pilote_servo_origine_B.Saturation = pilote_servo_origine_P.Constant_Value;
  }

  /* End of Saturate: '<S2>/Saturation' */

  /* Level2 S-Function Block: '<S2>/PWM' (Servo_PWM) */
  {
    SimStruct *rts = pilote_servo_origine_M->childSfunctions[2];
    sfcnOutputs(rts, 0);
  }

  /* Gain: '<S2>/PWMGain' */
  pilote_servo_origine_B.PWMGain = pilote_servo_origine_P.PWMGain_Gain *
    pilote_servo_origine_B.PWM;

  /* Level2 S-Function Block: '<S2>/ResetEncoder' (Servo_ResetEncoder) */
  {
    SimStruct *rts = pilote_servo_origine_M->childSfunctions[3];
    sfcnOutputs(rts, 0);
  }

  /* Gain: '<S2>/ResetEncoderGain' */
  pilote_servo_origine_B.ResetEncoderGain[0] =
    pilote_servo_origine_P.ResetEncoderGain_Gain *
    pilote_servo_origine_B.ResetEncoder[0];
  pilote_servo_origine_B.ResetEncoderGain[1] =
    pilote_servo_origine_P.ResetEncoderGain_Gain *
    pilote_servo_origine_B.ResetEncoder[1];

  /* Level2 S-Function Block: '<S2>/Bitstream Version' (Servo_BitstreamVersion) */
  {
    SimStruct *rts = pilote_servo_origine_M->childSfunctions[4];
    sfcnOutputs(rts, 0);
  }

  /* Level2 S-Function Block: '<S2>/PWMPrescaler' (Servo_PWMPrescaler) */
  {
    SimStruct *rts = pilote_servo_origine_M->childSfunctions[5];
    sfcnOutputs(rts, 0);
  }

  /* Gain: '<S2>/PWMPrescalerGain' */
  pilote_servo_origine_B.PWMPrescalerGain =
    pilote_servo_origine_P.PWMPrescalerGain_Gain *
    pilote_servo_origine_B.PWMPrescaler;

  /* Level2 S-Function Block: '<S2>/Therm Status' (Servo_PWMTherm) */
  {
    SimStruct *rts = pilote_servo_origine_M->childSfunctions[6];
    sfcnOutputs(rts, 0);
  }

  /* Gain: '<S2>/PWM Therm Status' */
  pilote_servo_origine_B.PWMThermStatus =
    pilote_servo_origine_P.PWMThermStatus_Gain *
    pilote_servo_origine_B.ThermStatus;

  /* Level2 S-Function Block: '<S2>/ThermFlag ' (Servo_ThermFlag) */
  {
    SimStruct *rts = pilote_servo_origine_M->childSfunctions[7];
    sfcnOutputs(rts, 0);
  }

  /* Gain: '<S2>/ThermFlagGain' */
  pilote_servo_origine_B.ThermFlagGain =
    pilote_servo_origine_P.ThermFlagGain_Gain * pilote_servo_origine_B.ThermFlag;
}

/* Model update function */
void pilote_servo_origine_update(void)
{
  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++pilote_servo_origine_M->Timing.clockTick0)) {
    ++pilote_servo_origine_M->Timing.clockTickH0;
  }

  pilote_servo_origine_M->Timing.t[0] =
    pilote_servo_origine_M->Timing.clockTick0 *
    pilote_servo_origine_M->Timing.stepSize0 +
    pilote_servo_origine_M->Timing.clockTickH0 *
    pilote_servo_origine_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void pilote_servo_origine_initialize(void)
{
}

/* Model terminate function */
void pilote_servo_origine_terminate(void)
{
  /* Level2 S-Function Block: '<S2>/Encoder' (Servo_Encoder) */
  {
    SimStruct *rts = pilote_servo_origine_M->childSfunctions[0];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S2>/RT-DAC Analog Inputs' (servo_analoginputs) */
  {
    SimStruct *rts = pilote_servo_origine_M->childSfunctions[1];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S2>/PWM' (Servo_PWM) */
  {
    SimStruct *rts = pilote_servo_origine_M->childSfunctions[2];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S2>/ResetEncoder' (Servo_ResetEncoder) */
  {
    SimStruct *rts = pilote_servo_origine_M->childSfunctions[3];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S2>/Bitstream Version' (Servo_BitstreamVersion) */
  {
    SimStruct *rts = pilote_servo_origine_M->childSfunctions[4];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S2>/PWMPrescaler' (Servo_PWMPrescaler) */
  {
    SimStruct *rts = pilote_servo_origine_M->childSfunctions[5];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S2>/Therm Status' (Servo_PWMTherm) */
  {
    SimStruct *rts = pilote_servo_origine_M->childSfunctions[6];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S2>/ThermFlag ' (Servo_ThermFlag) */
  {
    SimStruct *rts = pilote_servo_origine_M->childSfunctions[7];
    sfcnTerminate(rts);
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/
void MdlOutputs(int_T tid)
{
  pilote_servo_origine_output();

  /* tid is required for a uniform function interface.
   * Argument tid is not used in the function. */
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  pilote_servo_origine_update();

  /* tid is required for a uniform function interface.
   * Argument tid is not used in the function. */
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  pilote_servo_origine_initialize();
}

void MdlTerminate(void)
{
  pilote_servo_origine_terminate();
}

RT_MODEL_pilote_servo_origine *pilote_servo_origine(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)pilote_servo_origine_M, 0,
                sizeof(RT_MODEL_pilote_servo_origine));
  rtsiSetSolverName(&pilote_servo_origine_M->solverInfo,"FixedStepDiscrete");
  pilote_servo_origine_M->solverInfoPtr = (&pilote_servo_origine_M->solverInfo);

  /* Initialize timing info */
  {
    int_T *mdlTsMap = pilote_servo_origine_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    pilote_servo_origine_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    pilote_servo_origine_M->Timing.sampleTimes =
      (&pilote_servo_origine_M->Timing.sampleTimesArray[0]);
    pilote_servo_origine_M->Timing.offsetTimes =
      (&pilote_servo_origine_M->Timing.offsetTimesArray[0]);

    /* task periods */
    pilote_servo_origine_M->Timing.sampleTimes[0] = (0.005);

    /* task offsets */
    pilote_servo_origine_M->Timing.offsetTimes[0] = (0.0);
  }

  rtmSetTPtr(pilote_servo_origine_M, &pilote_servo_origine_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = pilote_servo_origine_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    pilote_servo_origine_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(pilote_servo_origine_M, -1);
  pilote_servo_origine_M->Timing.stepSize0 = 0.005;

  /* External mode info */
  pilote_servo_origine_M->Sizes.checksums[0] = (2858075955U);
  pilote_servo_origine_M->Sizes.checksums[1] = (4077253501U);
  pilote_servo_origine_M->Sizes.checksums[2] = (2826110514U);
  pilote_servo_origine_M->Sizes.checksums[3] = (2833685599U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[3];
    pilote_servo_origine_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(pilote_servo_origine_M->extModeInfo,
      &pilote_servo_origine_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(pilote_servo_origine_M->extModeInfo,
                        pilote_servo_origine_M->Sizes.checksums);
    rteiSetTPtr(pilote_servo_origine_M->extModeInfo, rtmGetTPtr
                (pilote_servo_origine_M));
  }

  pilote_servo_origine_M->solverInfoPtr = (&pilote_servo_origine_M->solverInfo);
  pilote_servo_origine_M->Timing.stepSize = (0.005);
  rtsiSetFixedStepSize(&pilote_servo_origine_M->solverInfo, 0.005);
  rtsiSetSolverMode(&pilote_servo_origine_M->solverInfo,
                    SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  pilote_servo_origine_M->ModelData.blockIO = ((void *) &pilote_servo_origine_B);

  {
    pilote_servo_origine_B.Encoder[0] = 0.0;
    pilote_servo_origine_B.Encoder[1] = 0.0;
    pilote_servo_origine_B.Converttorad[0] = 0.0;
    pilote_servo_origine_B.Converttorad[1] = 0.0;
    pilote_servo_origine_B.RTDACAnalogInputs[0] = 0.0;
    pilote_servo_origine_B.RTDACAnalogInputs[1] = 0.0;
    pilote_servo_origine_B.Converttorads = 0.0;
    pilote_servo_origine_B.SwitchControl = 0.0;
    pilote_servo_origine_B.Saturation = 0.0;
    pilote_servo_origine_B.PWM = 0.0;
    pilote_servo_origine_B.PWMGain = 0.0;
    pilote_servo_origine_B.ResetEncoder[0] = 0.0;
    pilote_servo_origine_B.ResetEncoder[1] = 0.0;
    pilote_servo_origine_B.ResetEncoderGain[0] = 0.0;
    pilote_servo_origine_B.ResetEncoderGain[1] = 0.0;
    pilote_servo_origine_B.BitstreamVersion = 0.0;
    pilote_servo_origine_B.PWMPrescaler = 0.0;
    pilote_servo_origine_B.PWMPrescalerGain = 0.0;
    pilote_servo_origine_B.ThermStatus = 0.0;
    pilote_servo_origine_B.PWMThermStatus = 0.0;
    pilote_servo_origine_B.ThermFlag = 0.0;
    pilote_servo_origine_B.ThermFlagGain = 0.0;
  }

  /* parameters */
  pilote_servo_origine_M->ModelData.defaultParam = ((real_T *)
    &pilote_servo_origine_P);

  /* states (dwork) */
  pilote_servo_origine_M->Work.dwork = ((void *) &pilote_servo_origine_DWork);
  (void) memset((void *)&pilote_servo_origine_DWork, 0,
                sizeof(D_Work_pilote_servo_origine));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    pilote_servo_origine_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 14;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.B = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.P = &rtPTransTable;
  }

  /* child S-Function registration */
  {
    RTWSfcnInfo *sfcnInfo = &pilote_servo_origine_M->NonInlinedSFcns.sfcnInfo;
    pilote_servo_origine_M->sfcnInfo = (sfcnInfo);
    rtssSetErrorStatusPtr(sfcnInfo, (&rtmGetErrorStatus(pilote_servo_origine_M)));
    rtssSetNumRootSampTimesPtr(sfcnInfo,
      &pilote_servo_origine_M->Sizes.numSampTimes);
    pilote_servo_origine_M->NonInlinedSFcns.taskTimePtrs[0] = &(rtmGetTPtr
      (pilote_servo_origine_M)[0]);
    rtssSetTPtrPtr(sfcnInfo,pilote_servo_origine_M->NonInlinedSFcns.taskTimePtrs);
    rtssSetTStartPtr(sfcnInfo, &rtmGetTStart(pilote_servo_origine_M));
    rtssSetTFinalPtr(sfcnInfo, &rtmGetTFinal(pilote_servo_origine_M));
    rtssSetTimeOfLastOutputPtr(sfcnInfo, &rtmGetTimeOfLastOutput
      (pilote_servo_origine_M));
    rtssSetStepSizePtr(sfcnInfo, &pilote_servo_origine_M->Timing.stepSize);
    rtssSetStopRequestedPtr(sfcnInfo, &rtmGetStopRequested
      (pilote_servo_origine_M));
    rtssSetDerivCacheNeedsResetPtr(sfcnInfo,
      &pilote_servo_origine_M->ModelData.derivCacheNeedsReset);
    rtssSetZCCacheNeedsResetPtr(sfcnInfo,
      &pilote_servo_origine_M->ModelData.zCCacheNeedsReset);
    rtssSetBlkStateChangePtr(sfcnInfo,
      &pilote_servo_origine_M->ModelData.blkStateChange);
    rtssSetSampleHitsPtr(sfcnInfo, &pilote_servo_origine_M->Timing.sampleHits);
    rtssSetPerTaskSampleHitsPtr(sfcnInfo,
      &pilote_servo_origine_M->Timing.perTaskSampleHits);
    rtssSetSimModePtr(sfcnInfo, &pilote_servo_origine_M->simMode);
    rtssSetSolverInfoPtr(sfcnInfo, &pilote_servo_origine_M->solverInfoPtr);
  }

  pilote_servo_origine_M->Sizes.numSFcns = (8);

  /* register each child */
  {
    (void) memset((void *)
                  &pilote_servo_origine_M->NonInlinedSFcns.childSFunctions[0], 0,
                  8*sizeof(SimStruct));
    pilote_servo_origine_M->childSfunctions =
      (&pilote_servo_origine_M->NonInlinedSFcns.childSFunctionPtrs[0]);

    {
      int_T i;
      for (i = 0; i < 8; i++) {
        pilote_servo_origine_M->childSfunctions[i] =
          (&pilote_servo_origine_M->NonInlinedSFcns.childSFunctions[i]);
      }
    }

    /* Level2 S-Function Block: pilote_servo_origine/<S2>/Encoder (Servo_Encoder) */
    {
      SimStruct *rts = pilote_servo_origine_M->childSfunctions[0];

      /* timing info */
      time_T *sfcnPeriod =
        pilote_servo_origine_M->NonInlinedSFcns.Sfcn0.sfcnPeriod;
      time_T *sfcnOffset =
        pilote_servo_origine_M->NonInlinedSFcns.Sfcn0.sfcnOffset;
      int_T *sfcnTsMap = pilote_servo_origine_M->NonInlinedSFcns.Sfcn0.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &pilote_servo_origine_M->NonInlinedSFcns.blkInfo2
                         [0]);
      }

      ssSetRTWSfcnInfo(rts, pilote_servo_origine_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &pilote_servo_origine_M->NonInlinedSFcns.methods2[0]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &pilote_servo_origine_M->NonInlinedSFcns.methods3[0]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &pilote_servo_origine_M->NonInlinedSFcns.statesInfo2[0]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &pilote_servo_origine_M->NonInlinedSFcns.Sfcn0.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 2);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            pilote_servo_origine_B.Encoder));
        }
      }

      /* path info */
      ssSetModelName(rts, "Encoder");
      ssSetPath(rts, "pilote_servo_origine/Servo/Encoder");
      ssSetRTModel(rts,pilote_servo_origine_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &pilote_servo_origine_M->NonInlinedSFcns.Sfcn0.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)pilote_servo_origine_P.Encoder_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)pilote_servo_origine_P.Encoder_P2_Size);
      }

      /* registration */
      Servo_Encoder(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: pilote_servo_origine/<S2>/RT-DAC Analog Inputs (servo_analoginputs) */
    {
      SimStruct *rts = pilote_servo_origine_M->childSfunctions[1];

      /* timing info */
      time_T *sfcnPeriod =
        pilote_servo_origine_M->NonInlinedSFcns.Sfcn1.sfcnPeriod;
      time_T *sfcnOffset =
        pilote_servo_origine_M->NonInlinedSFcns.Sfcn1.sfcnOffset;
      int_T *sfcnTsMap = pilote_servo_origine_M->NonInlinedSFcns.Sfcn1.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &pilote_servo_origine_M->NonInlinedSFcns.blkInfo2
                         [1]);
      }

      ssSetRTWSfcnInfo(rts, pilote_servo_origine_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &pilote_servo_origine_M->NonInlinedSFcns.methods2[1]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &pilote_servo_origine_M->NonInlinedSFcns.methods3[1]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &pilote_servo_origine_M->NonInlinedSFcns.statesInfo2[1]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &pilote_servo_origine_M->NonInlinedSFcns.Sfcn1.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 2);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            pilote_servo_origine_B.RTDACAnalogInputs));
        }
      }

      /* path info */
      ssSetModelName(rts, "RT-DAC\nAnalog Inputs");
      ssSetPath(rts, "pilote_servo_origine/Servo/RT-DAC Analog Inputs");
      ssSetRTModel(rts,pilote_servo_origine_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &pilote_servo_origine_M->NonInlinedSFcns.Sfcn1.params;
        ssSetSFcnParamsCount(rts, 4);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       pilote_servo_origine_P.RTDACAnalogInputs_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       pilote_servo_origine_P.RTDACAnalogInputs_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       pilote_servo_origine_P.RTDACAnalogInputs_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       pilote_servo_origine_P.RTDACAnalogInputs_P4_Size);
      }

      /* registration */
      servo_analoginputs(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: pilote_servo_origine/<S2>/PWM (Servo_PWM) */
    {
      SimStruct *rts = pilote_servo_origine_M->childSfunctions[2];

      /* timing info */
      time_T *sfcnPeriod =
        pilote_servo_origine_M->NonInlinedSFcns.Sfcn2.sfcnPeriod;
      time_T *sfcnOffset =
        pilote_servo_origine_M->NonInlinedSFcns.Sfcn2.sfcnOffset;
      int_T *sfcnTsMap = pilote_servo_origine_M->NonInlinedSFcns.Sfcn2.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &pilote_servo_origine_M->NonInlinedSFcns.blkInfo2
                         [2]);
      }

      ssSetRTWSfcnInfo(rts, pilote_servo_origine_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &pilote_servo_origine_M->NonInlinedSFcns.methods2[2]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &pilote_servo_origine_M->NonInlinedSFcns.methods3[2]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &pilote_servo_origine_M->NonInlinedSFcns.statesInfo2[2]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &pilote_servo_origine_M->NonInlinedSFcns.Sfcn2.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &pilote_servo_origine_M->NonInlinedSFcns.Sfcn2.UPtrs0;
          sfcnUPtrs[0] = &pilote_servo_origine_B.Saturation;
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &pilote_servo_origine_M->NonInlinedSFcns.Sfcn2.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &pilote_servo_origine_B.PWM));
        }
      }

      /* path info */
      ssSetModelName(rts, "PWM");
      ssSetPath(rts, "pilote_servo_origine/Servo/PWM");
      ssSetRTModel(rts,pilote_servo_origine_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &pilote_servo_origine_M->NonInlinedSFcns.Sfcn2.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)pilote_servo_origine_P.PWM_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)pilote_servo_origine_P.PWM_P2_Size);
      }

      /* registration */
      Servo_PWM(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: pilote_servo_origine/<S2>/ResetEncoder (Servo_ResetEncoder) */
    {
      SimStruct *rts = pilote_servo_origine_M->childSfunctions[3];

      /* timing info */
      time_T *sfcnPeriod =
        pilote_servo_origine_M->NonInlinedSFcns.Sfcn3.sfcnPeriod;
      time_T *sfcnOffset =
        pilote_servo_origine_M->NonInlinedSFcns.Sfcn3.sfcnOffset;
      int_T *sfcnTsMap = pilote_servo_origine_M->NonInlinedSFcns.Sfcn3.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &pilote_servo_origine_M->NonInlinedSFcns.blkInfo2
                         [3]);
      }

      ssSetRTWSfcnInfo(rts, pilote_servo_origine_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &pilote_servo_origine_M->NonInlinedSFcns.methods2[3]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &pilote_servo_origine_M->NonInlinedSFcns.methods3[3]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &pilote_servo_origine_M->NonInlinedSFcns.statesInfo2[3]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &pilote_servo_origine_M->NonInlinedSFcns.Sfcn3.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &pilote_servo_origine_M->NonInlinedSFcns.Sfcn3.UPtrs0;
          sfcnUPtrs[0] = &pilote_servo_origine_B.SwitchControl;
          sfcnUPtrs[1] = &pilote_servo_origine_B.SwitchControl;
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 2);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &pilote_servo_origine_M->NonInlinedSFcns.Sfcn3.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 2);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            pilote_servo_origine_B.ResetEncoder));
        }
      }

      /* path info */
      ssSetModelName(rts, "ResetEncoder");
      ssSetPath(rts, "pilote_servo_origine/Servo/ResetEncoder");
      ssSetRTModel(rts,pilote_servo_origine_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &pilote_servo_origine_M->NonInlinedSFcns.Sfcn3.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       pilote_servo_origine_P.ResetEncoder_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       pilote_servo_origine_P.ResetEncoder_P2_Size);
      }

      /* registration */
      Servo_ResetEncoder(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: pilote_servo_origine/<S2>/Bitstream Version (Servo_BitstreamVersion) */
    {
      SimStruct *rts = pilote_servo_origine_M->childSfunctions[4];

      /* timing info */
      time_T *sfcnPeriod =
        pilote_servo_origine_M->NonInlinedSFcns.Sfcn4.sfcnPeriod;
      time_T *sfcnOffset =
        pilote_servo_origine_M->NonInlinedSFcns.Sfcn4.sfcnOffset;
      int_T *sfcnTsMap = pilote_servo_origine_M->NonInlinedSFcns.Sfcn4.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &pilote_servo_origine_M->NonInlinedSFcns.blkInfo2
                         [4]);
      }

      ssSetRTWSfcnInfo(rts, pilote_servo_origine_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &pilote_servo_origine_M->NonInlinedSFcns.methods2[4]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &pilote_servo_origine_M->NonInlinedSFcns.methods3[4]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &pilote_servo_origine_M->NonInlinedSFcns.statesInfo2[4]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &pilote_servo_origine_M->NonInlinedSFcns.Sfcn4.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &pilote_servo_origine_B.BitstreamVersion));
        }
      }

      /* path info */
      ssSetModelName(rts, "Bitstream Version");
      ssSetPath(rts, "pilote_servo_origine/Servo/Bitstream Version");
      ssSetRTModel(rts,pilote_servo_origine_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &pilote_servo_origine_M->NonInlinedSFcns.Sfcn4.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       pilote_servo_origine_P.BitstreamVersion_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       pilote_servo_origine_P.BitstreamVersion_P2_Size);
      }

      /* registration */
      Servo_BitstreamVersion(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: pilote_servo_origine/<S2>/PWMPrescaler (Servo_PWMPrescaler) */
    {
      SimStruct *rts = pilote_servo_origine_M->childSfunctions[5];

      /* timing info */
      time_T *sfcnPeriod =
        pilote_servo_origine_M->NonInlinedSFcns.Sfcn5.sfcnPeriod;
      time_T *sfcnOffset =
        pilote_servo_origine_M->NonInlinedSFcns.Sfcn5.sfcnOffset;
      int_T *sfcnTsMap = pilote_servo_origine_M->NonInlinedSFcns.Sfcn5.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &pilote_servo_origine_M->NonInlinedSFcns.blkInfo2
                         [5]);
      }

      ssSetRTWSfcnInfo(rts, pilote_servo_origine_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &pilote_servo_origine_M->NonInlinedSFcns.methods2[5]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &pilote_servo_origine_M->NonInlinedSFcns.methods3[5]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &pilote_servo_origine_M->NonInlinedSFcns.statesInfo2[5]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &pilote_servo_origine_M->NonInlinedSFcns.Sfcn5.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &pilote_servo_origine_M->NonInlinedSFcns.Sfcn5.UPtrs0;
          sfcnUPtrs[0] = &pilote_servo_origine_P.PWMPrescalerSource_Value;
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &pilote_servo_origine_M->NonInlinedSFcns.Sfcn5.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &pilote_servo_origine_B.PWMPrescaler));
        }
      }

      /* path info */
      ssSetModelName(rts, "PWMPrescaler");
      ssSetPath(rts, "pilote_servo_origine/Servo/PWMPrescaler");
      ssSetRTModel(rts,pilote_servo_origine_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &pilote_servo_origine_M->NonInlinedSFcns.Sfcn5.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       pilote_servo_origine_P.PWMPrescaler_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       pilote_servo_origine_P.PWMPrescaler_P2_Size);
      }

      /* registration */
      Servo_PWMPrescaler(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: pilote_servo_origine/<S2>/Therm Status (Servo_PWMTherm) */
    {
      SimStruct *rts = pilote_servo_origine_M->childSfunctions[6];

      /* timing info */
      time_T *sfcnPeriod =
        pilote_servo_origine_M->NonInlinedSFcns.Sfcn6.sfcnPeriod;
      time_T *sfcnOffset =
        pilote_servo_origine_M->NonInlinedSFcns.Sfcn6.sfcnOffset;
      int_T *sfcnTsMap = pilote_servo_origine_M->NonInlinedSFcns.Sfcn6.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &pilote_servo_origine_M->NonInlinedSFcns.blkInfo2
                         [6]);
      }

      ssSetRTWSfcnInfo(rts, pilote_servo_origine_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &pilote_servo_origine_M->NonInlinedSFcns.methods2[6]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &pilote_servo_origine_M->NonInlinedSFcns.methods3[6]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &pilote_servo_origine_M->NonInlinedSFcns.statesInfo2[6]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &pilote_servo_origine_M->NonInlinedSFcns.Sfcn6.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &pilote_servo_origine_B.ThermStatus));
        }
      }

      /* path info */
      ssSetModelName(rts, "Therm Status");
      ssSetPath(rts, "pilote_servo_origine/Servo/Therm Status");
      ssSetRTModel(rts,pilote_servo_origine_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &pilote_servo_origine_M->NonInlinedSFcns.Sfcn6.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       pilote_servo_origine_P.ThermStatus_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       pilote_servo_origine_P.ThermStatus_P2_Size);
      }

      /* registration */
      Servo_PWMTherm(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: pilote_servo_origine/<S2>/ThermFlag  (Servo_ThermFlag) */
    {
      SimStruct *rts = pilote_servo_origine_M->childSfunctions[7];

      /* timing info */
      time_T *sfcnPeriod =
        pilote_servo_origine_M->NonInlinedSFcns.Sfcn7.sfcnPeriod;
      time_T *sfcnOffset =
        pilote_servo_origine_M->NonInlinedSFcns.Sfcn7.sfcnOffset;
      int_T *sfcnTsMap = pilote_servo_origine_M->NonInlinedSFcns.Sfcn7.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &pilote_servo_origine_M->NonInlinedSFcns.blkInfo2
                         [7]);
      }

      ssSetRTWSfcnInfo(rts, pilote_servo_origine_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &pilote_servo_origine_M->NonInlinedSFcns.methods2[7]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &pilote_servo_origine_M->NonInlinedSFcns.methods3[7]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &pilote_servo_origine_M->NonInlinedSFcns.statesInfo2[7]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &pilote_servo_origine_M->NonInlinedSFcns.Sfcn7.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &pilote_servo_origine_M->NonInlinedSFcns.Sfcn7.UPtrs0;
          sfcnUPtrs[0] = &pilote_servo_origine_P.ThermFlagSource_Value;
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &pilote_servo_origine_M->NonInlinedSFcns.Sfcn7.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &pilote_servo_origine_B.ThermFlag));
        }
      }

      /* path info */
      ssSetModelName(rts, "ThermFlag ");
      ssSetPath(rts, "pilote_servo_origine/Servo/ThermFlag ");
      ssSetRTModel(rts,pilote_servo_origine_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &pilote_servo_origine_M->NonInlinedSFcns.Sfcn7.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       pilote_servo_origine_P.ThermFlag_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       pilote_servo_origine_P.ThermFlag_P2_Size);
      }

      /* registration */
      Servo_ThermFlag(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }
  }

  /* Initialize Sizes */
  pilote_servo_origine_M->Sizes.numContStates = (0);/* Number of continuous states */
  pilote_servo_origine_M->Sizes.numY = (0);/* Number of model outputs */
  pilote_servo_origine_M->Sizes.numU = (0);/* Number of model inputs */
  pilote_servo_origine_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  pilote_servo_origine_M->Sizes.numSampTimes = (1);/* Number of sample times */
  pilote_servo_origine_M->Sizes.numBlocks = (36);/* Number of blocks */
  pilote_servo_origine_M->Sizes.numBlockIO = (17);/* Number of block outputs */
  pilote_servo_origine_M->Sizes.numBlockPrms = (73);/* Sum of parameter "widths" */
  return pilote_servo_origine_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
