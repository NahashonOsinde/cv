/*
 * pilote_servo_origine_data.c
 *
 * Code generation for model "pilote_servo_origine".
 *
 * Model version              : 1.248
 * Simulink Coder version : 8.2 (R2012a) 29-Dec-2011
 * C source code generated on : Fri Nov 20 14:20:27 2020
 *
 * Target selection: rtwin.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#include "pilote_servo_origine.h"
#include "pilote_servo_origine_private.h"

/* Block parameters (auto storage) */
Parameters_pilote_servo_origine pilote_servo_origine_P = {
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/Normal'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<Root>/Reset'
                                        */

  /*  Computed Parameter: Encoder_P1_Size
   * Referenced by: '<S2>/Encoder'
   */
  { 1.0, 1.0 },
  4352.0,                              /* Expression: BaseAddress
                                        * Referenced by: '<S2>/Encoder'
                                        */

  /*  Computed Parameter: Encoder_P2_Size
   * Referenced by: '<S2>/Encoder'
   */
  { 1.0, 1.0 },
  0.005,                               /* Expression: T0
                                        * Referenced by: '<S2>/Encoder'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S2>/Encoder 1024 PPR'
                                        */
  0.0015339807878856412,               /* Expression: 2*pi/4096
                                        * Referenced by: '<S2>/Convert to rad'
                                        */

  /*  Computed Parameter: RTDACAnalogInputs_P1_Size
   * Referenced by: '<S2>/RT-DAC Analog Inputs'
   */
  { 1.0, 1.0 },
  4352.0,                              /* Expression: BaseAddress
                                        * Referenced by: '<S2>/RT-DAC Analog Inputs'
                                        */

  /*  Computed Parameter: RTDACAnalogInputs_P2_Size
   * Referenced by: '<S2>/RT-DAC Analog Inputs'
   */
  { 1.0, 2.0 },

  /*  Expression: [1 0]
   * Referenced by: '<S2>/RT-DAC Analog Inputs'
   */
  { 1.0, 0.0 },

  /*  Computed Parameter: RTDACAnalogInputs_P3_Size
   * Referenced by: '<S2>/RT-DAC Analog Inputs'
   */
  { 1.0, 2.0 },

  /*  Expression: [1 1]
   * Referenced by: '<S2>/RT-DAC Analog Inputs'
   */
  { 1.0, 1.0 },

  /*  Computed Parameter: RTDACAnalogInputs_P4_Size
   * Referenced by: '<S2>/RT-DAC Analog Inputs'
   */
  { 1.0, 1.0 },
  0.005,                               /* Expression: T0
                                        * Referenced by: '<S2>/RT-DAC Analog Inputs'
                                        */
  20.4,                                /* Expression: 20.4
                                        * Referenced by: '<S2>/Convert to rad//s'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/Constant'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S2>/Saturation'
                                        */
  -1.0,                                /* Expression: -1
                                        * Referenced by: '<S2>/Saturation'
                                        */

  /*  Computed Parameter: PWM_P1_Size
   * Referenced by: '<S2>/PWM'
   */
  { 1.0, 1.0 },
  4352.0,                              /* Expression: BaseAddress
                                        * Referenced by: '<S2>/PWM'
                                        */

  /*  Computed Parameter: PWM_P2_Size
   * Referenced by: '<S2>/PWM'
   */
  { 1.0, 1.0 },
  0.005,                               /* Expression: T0
                                        * Referenced by: '<S2>/PWM'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S2>/PWMGain'
                                        */

  /*  Computed Parameter: ResetEncoder_P1_Size
   * Referenced by: '<S2>/ResetEncoder'
   */
  { 1.0, 1.0 },
  4352.0,                              /* Expression: BaseAddress
                                        * Referenced by: '<S2>/ResetEncoder'
                                        */

  /*  Computed Parameter: ResetEncoder_P2_Size
   * Referenced by: '<S2>/ResetEncoder'
   */
  { 1.0, 1.0 },
  0.005,                               /* Expression: T0
                                        * Referenced by: '<S2>/ResetEncoder'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S2>/ResetEncoderGain'
                                        */

  /*  Computed Parameter: BitstreamVersion_P1_Size
   * Referenced by: '<S2>/Bitstream Version'
   */
  { 1.0, 1.0 },
  4352.0,                              /* Expression: BaseAddress
                                        * Referenced by: '<S2>/Bitstream Version'
                                        */

  /*  Computed Parameter: BitstreamVersion_P2_Size
   * Referenced by: '<S2>/Bitstream Version'
   */
  { 1.0, 1.0 },
  0.005,                               /* Expression: T0
                                        * Referenced by: '<S2>/Bitstream Version'
                                        */
  2.0,                                 /* Expression: 2
                                        * Referenced by: '<S2>/PWMPrescalerSource'
                                        */

  /*  Computed Parameter: PWMPrescaler_P1_Size
   * Referenced by: '<S2>/PWMPrescaler'
   */
  { 1.0, 1.0 },
  4352.0,                              /* Expression: BaseAddress
                                        * Referenced by: '<S2>/PWMPrescaler'
                                        */

  /*  Computed Parameter: PWMPrescaler_P2_Size
   * Referenced by: '<S2>/PWMPrescaler'
   */
  { 1.0, 1.0 },
  0.005,                               /* Expression: T0
                                        * Referenced by: '<S2>/PWMPrescaler'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S2>/PWMPrescalerGain'
                                        */

  /*  Computed Parameter: ThermStatus_P1_Size
   * Referenced by: '<S2>/Therm Status'
   */
  { 1.0, 1.0 },
  4352.0,                              /* Expression: BaseAddress
                                        * Referenced by: '<S2>/Therm Status'
                                        */

  /*  Computed Parameter: ThermStatus_P2_Size
   * Referenced by: '<S2>/Therm Status'
   */
  { 1.0, 1.0 },
  0.005,                               /* Expression: T0
                                        * Referenced by: '<S2>/Therm Status'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S2>/PWM Therm Status'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S2>/ThermFlagSource'
                                        */

  /*  Computed Parameter: ThermFlag_P1_Size
   * Referenced by: '<S2>/ThermFlag '
   */
  { 1.0, 1.0 },
  4352.0,                              /* Expression: BaseAddress
                                        * Referenced by: '<S2>/ThermFlag '
                                        */

  /*  Computed Parameter: ThermFlag_P2_Size
   * Referenced by: '<S2>/ThermFlag '
   */
  { 1.0, 1.0 },
  0.005,                               /* Expression: T0
                                        * Referenced by: '<S2>/ThermFlag '
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S2>/ThermFlagGain'
                                        */
  1U,                                  /* Expression: uint8(1)
                                        * Referenced by: '<S1>/Constant'
                                        */
  1U                                   /* Expression: uint8(1)
                                        * Referenced by: '<S1>/SwitchControl'
                                        */
};
