/*
 *  rtmodel.h:
 *
 * Code generation for model "pilote_servo_origine".
 *
 * Model version              : 1.248
 * Simulink Coder version : 8.2 (R2012a) 29-Dec-2011
 * C source code generated on : Fri Nov 20 14:20:27 2020
 *
 * Target selection: rtwin.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#ifndef RTW_HEADER_rtmodel_h_
#define RTW_HEADER_rtmodel_h_

/*
 *  Includes the appropriate headers when we are using rtModel
 */
#include "pilote_servo_origine.h"
#define GRTINTERFACE                   1
#define ONESTEPFCN                     0
#endif                                 /* RTW_HEADER_rtmodel_h_ */
