/*
 * pilote_maquette_niveau_data.c
 *
 * Code generation for model "pilote_maquette_niveau".
 *
 * Model version              : 1.205
 * Simulink Coder version : 8.2 (R2012a) 29-Dec-2011
 * C source code generated on : Fri Nov 20 15:52:56 2020
 *
 * Target selection: rtwin.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#include "pilote_maquette_niveau.h"
#include "pilote_maquette_niveau_private.h"

/* Block parameters (auto storage) */
Parameters_pilote_maquette_niveau pilote_maquette_niveau_P = {
  /*  Computed Parameter: RTDACFrequencies_P1_Size
   * Referenced by: '<S2>/RT-DAC Frequencies'
   */
  { 1.0, 1.0 },
  4352.0,                              /* Expression: BaseAddress
                                        * Referenced by: '<S2>/RT-DAC Frequencies'
                                        */

  /*  Computed Parameter: RTDACFrequencies_P2_Size
   * Referenced by: '<S2>/RT-DAC Frequencies'
   */
  { 1.0, 1.0 },
  0.01,                                /* Expression: T0
                                        * Referenced by: '<S2>/RT-DAC Frequencies'
                                        */
  2282.916489235864,                   /* Expression: GetBias(1)
                                        * Referenced by: '<S1>/Tank 1 Bias'
                                        */
  0.00014194461775694585,              /* Expression: GetScaleCoeff(1)
                                        * Referenced by: '<S1>/Tank 1 Scale'
                                        */

  /*  Computed Parameter: RTDACSafetyAlert_P1_Size
   * Referenced by: '<S3>/RT-DAC Safety Alert'
   */
  { 1.0, 1.0 },
  4352.0,                              /* Expression: BaseAddress
                                        * Referenced by: '<S3>/RT-DAC Safety Alert'
                                        */

  /*  Computed Parameter: RTDACSafetyAlert_P2_Size
   * Referenced by: '<S3>/RT-DAC Safety Alert'
   */
  { 1.0, 1.0 },
  0.01,                                /* Expression: T0
                                        * Referenced by: '<S3>/RT-DAC Safety Alert'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/Valve 4'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S1>/Saturation Control Pump'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S1>/Saturation Control Pump'
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P1_Size
   * Referenced by: '<S4>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  4352.0,                              /* Expression: BaseAddress
                                        * Referenced by: '<S4>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P2_Size
   * Referenced by: '<S4>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: ChanIdx
                                        * Referenced by: '<S4>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P3_Size
   * Referenced by: '<S4>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  2.0,                                 /* Expression: ChanMode
                                        * Referenced by: '<S4>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P4_Size
   * Referenced by: '<S4>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: ChanPresc
                                        * Referenced by: '<S4>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P5_Size
   * Referenced by: '<S4>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: SetOutputsFlag
                                        * Referenced by: '<S4>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P6_Size
   * Referenced by: '<S4>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: SetOutputsValue
                                        * Referenced by: '<S4>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P7_Size
   * Referenced by: '<S4>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  0.01,                                /* Expression: T0
                                        * Referenced by: '<S4>/RT-DAC PCI PWM '
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/Valve 1'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S1>/Saturation Control Valve 1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S1>/Saturation Control Valve 1'
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P1_Size_m
   * Referenced by: '<S5>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  4352.0,                              /* Expression: BaseAddress
                                        * Referenced by: '<S5>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P2_Size_m
   * Referenced by: '<S5>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  4.0,                                 /* Expression: ChanIdx
                                        * Referenced by: '<S5>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P3_Size_n
   * Referenced by: '<S5>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  2.0,                                 /* Expression: ChanMode
                                        * Referenced by: '<S5>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P4_Size_h
   * Referenced by: '<S5>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  31.0,                                /* Expression: ChanPresc
                                        * Referenced by: '<S5>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P5_Size_e
   * Referenced by: '<S5>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: SetOutputsFlag
                                        * Referenced by: '<S5>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P6_Size_e
   * Referenced by: '<S5>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: SetOutputsValue
                                        * Referenced by: '<S5>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P7_Size_h
   * Referenced by: '<S5>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  0.01,                                /* Expression: T0
                                        * Referenced by: '<S5>/RT-DAC PCI PWM '
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/Valve 2'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S1>/Saturation Control Valve 2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S1>/Saturation Control Valve 2'
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P1_Size_e
   * Referenced by: '<S6>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  4352.0,                              /* Expression: BaseAddress
                                        * Referenced by: '<S6>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P2_Size_d
   * Referenced by: '<S6>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  3.0,                                 /* Expression: ChanIdx
                                        * Referenced by: '<S6>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P3_Size_g
   * Referenced by: '<S6>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  2.0,                                 /* Expression: ChanMode
                                        * Referenced by: '<S6>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P4_Size_o
   * Referenced by: '<S6>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  31.0,                                /* Expression: ChanPresc
                                        * Referenced by: '<S6>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P5_Size_g
   * Referenced by: '<S6>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: SetOutputsFlag
                                        * Referenced by: '<S6>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P6_Size_c
   * Referenced by: '<S6>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: SetOutputsValue
                                        * Referenced by: '<S6>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P7_Size_c
   * Referenced by: '<S6>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  0.01,                                /* Expression: T0
                                        * Referenced by: '<S6>/RT-DAC PCI PWM '
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/Valve 3'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S1>/Saturation Control Valve 3'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S1>/Saturation Control Valve 3'
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P1_Size_p
   * Referenced by: '<S7>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  4352.0,                              /* Expression: BaseAddress
                                        * Referenced by: '<S7>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P2_Size_f
   * Referenced by: '<S7>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  2.0,                                 /* Expression: ChanIdx
                                        * Referenced by: '<S7>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P3_Size_d
   * Referenced by: '<S7>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  2.0,                                 /* Expression: ChanMode
                                        * Referenced by: '<S7>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P4_Size_d
   * Referenced by: '<S7>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  31.0,                                /* Expression: ChanPresc
                                        * Referenced by: '<S7>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P5_Size_m
   * Referenced by: '<S7>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: SetOutputsFlag
                                        * Referenced by: '<S7>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P6_Size_f
   * Referenced by: '<S7>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: SetOutputsValue
                                        * Referenced by: '<S7>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P7_Size_a
   * Referenced by: '<S7>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  0.01,                                /* Expression: T0
                                        * Referenced by: '<S7>/RT-DAC PCI PWM '
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S1>/Valve 4'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S1>/Saturation Control Valve 4'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S1>/Saturation Control Valve 4'
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P1_Size_l
   * Referenced by: '<S8>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  4352.0,                              /* Expression: BaseAddress
                                        * Referenced by: '<S8>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P2_Size_p
   * Referenced by: '<S8>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  6.0,                                 /* Expression: ChanIdx
                                        * Referenced by: '<S8>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P3_Size_e
   * Referenced by: '<S8>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  2.0,                                 /* Expression: ChanMode
                                        * Referenced by: '<S8>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P4_Size_b
   * Referenced by: '<S8>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  31.0,                                /* Expression: ChanPresc
                                        * Referenced by: '<S8>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P5_Size_a
   * Referenced by: '<S8>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: SetOutputsFlag
                                        * Referenced by: '<S8>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P6_Size_ee
   * Referenced by: '<S8>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: SetOutputsValue
                                        * Referenced by: '<S8>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P7_Size_g
   * Referenced by: '<S8>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  0.01,                                /* Expression: T0
                                        * Referenced by: '<S8>/RT-DAC PCI PWM '
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S1>/Valve 5'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S1>/Saturation Control Valve 5'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S1>/Saturation Control Valve 5'
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P1_Size_h
   * Referenced by: '<S9>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  4352.0,                              /* Expression: BaseAddress
                                        * Referenced by: '<S9>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P2_Size_i
   * Referenced by: '<S9>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  5.0,                                 /* Expression: ChanIdx
                                        * Referenced by: '<S9>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P3_Size_l
   * Referenced by: '<S9>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  2.0,                                 /* Expression: ChanMode
                                        * Referenced by: '<S9>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P4_Size_dn
   * Referenced by: '<S9>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  31.0,                                /* Expression: ChanPresc
                                        * Referenced by: '<S9>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P5_Size_an
   * Referenced by: '<S9>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: SetOutputsFlag
                                        * Referenced by: '<S9>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P6_Size_d
   * Referenced by: '<S9>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: SetOutputsValue
                                        * Referenced by: '<S9>/RT-DAC PCI PWM '
                                        */

  /*  Computed Parameter: RTDACPCIPWM_P7_Size_n
   * Referenced by: '<S9>/RT-DAC PCI PWM '
   */
  { 1.0, 1.0 },
  0.01                                 /* Expression: T0
                                        * Referenced by: '<S9>/RT-DAC PCI PWM '
                                        */
};
