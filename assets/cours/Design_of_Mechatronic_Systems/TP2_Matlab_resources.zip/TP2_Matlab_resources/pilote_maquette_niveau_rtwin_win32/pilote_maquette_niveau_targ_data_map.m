  function targMap = targDataMap(),

  ;%***********************
  ;% Create Parameter Map *
  ;%***********************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 1;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc paramMap
    ;%
    paramMap.nSections           = nTotSects;
    paramMap.sectIdxOffset       = sectIdxOffset;
      paramMap.sections(nTotSects) = dumSection; %prealloc
    paramMap.nTotData            = -1;
    
    ;%
    ;% Auto data (pilote_maquette_niveau_P)
    ;%
      section.nData     = 112;
      section.data(112)  = dumData; %prealloc
      
	  ;% pilote_maquette_niveau_P.RTDACFrequencies_P1_Size
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% pilote_maquette_niveau_P.RTDACFrequencies_P1
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 2;
	
	  ;% pilote_maquette_niveau_P.RTDACFrequencies_P2_Size
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 3;
	
	  ;% pilote_maquette_niveau_P.RTDACFrequencies_P2
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 5;
	
	  ;% pilote_maquette_niveau_P.Tank1Bias_Value
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 6;
	
	  ;% pilote_maquette_niveau_P.Tank1Scale_Gain
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 7;
	
	  ;% pilote_maquette_niveau_P.RTDACSafetyAlert_P1_Size
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 8;
	
	  ;% pilote_maquette_niveau_P.RTDACSafetyAlert_P1
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 10;
	
	  ;% pilote_maquette_niveau_P.RTDACSafetyAlert_P2_Size
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 11;
	
	  ;% pilote_maquette_niveau_P.RTDACSafetyAlert_P2
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 13;
	
	  ;% pilote_maquette_niveau_P.Valve4_Value
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 14;
	
	  ;% pilote_maquette_niveau_P.SaturationControlPump_UpperSat
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 15;
	
	  ;% pilote_maquette_niveau_P.SaturationControlPump_LowerSat
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 16;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P1_Size
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 17;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P1
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 19;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P2_Size
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 20;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P2
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 22;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P3_Size
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 23;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P3
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 25;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P4_Size
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 26;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P4
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 28;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P5_Size
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 29;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P5
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 31;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P6_Size
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 32;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P6
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 34;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P7_Size
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 35;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P7
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 37;
	
	  ;% pilote_maquette_niveau_P.Valve1_Value
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 38;
	
	  ;% pilote_maquette_niveau_P.SaturationControlValve1_UpperSat
	  section.data(29).logicalSrcIdx = 28;
	  section.data(29).dtTransOffset = 39;
	
	  ;% pilote_maquette_niveau_P.SaturationControlValve1_LowerSat
	  section.data(30).logicalSrcIdx = 29;
	  section.data(30).dtTransOffset = 40;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P1_Size_m
	  section.data(31).logicalSrcIdx = 30;
	  section.data(31).dtTransOffset = 41;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P1_j
	  section.data(32).logicalSrcIdx = 31;
	  section.data(32).dtTransOffset = 43;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P2_Size_m
	  section.data(33).logicalSrcIdx = 32;
	  section.data(33).dtTransOffset = 44;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P2_h
	  section.data(34).logicalSrcIdx = 33;
	  section.data(34).dtTransOffset = 46;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P3_Size_n
	  section.data(35).logicalSrcIdx = 34;
	  section.data(35).dtTransOffset = 47;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P3_i
	  section.data(36).logicalSrcIdx = 35;
	  section.data(36).dtTransOffset = 49;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P4_Size_h
	  section.data(37).logicalSrcIdx = 36;
	  section.data(37).dtTransOffset = 50;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P4_l
	  section.data(38).logicalSrcIdx = 37;
	  section.data(38).dtTransOffset = 52;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P5_Size_e
	  section.data(39).logicalSrcIdx = 38;
	  section.data(39).dtTransOffset = 53;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P5_n
	  section.data(40).logicalSrcIdx = 39;
	  section.data(40).dtTransOffset = 55;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P6_Size_e
	  section.data(41).logicalSrcIdx = 40;
	  section.data(41).dtTransOffset = 56;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P6_b
	  section.data(42).logicalSrcIdx = 41;
	  section.data(42).dtTransOffset = 58;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P7_Size_h
	  section.data(43).logicalSrcIdx = 42;
	  section.data(43).dtTransOffset = 59;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P7_p
	  section.data(44).logicalSrcIdx = 43;
	  section.data(44).dtTransOffset = 61;
	
	  ;% pilote_maquette_niveau_P.Valve2_Value
	  section.data(45).logicalSrcIdx = 44;
	  section.data(45).dtTransOffset = 62;
	
	  ;% pilote_maquette_niveau_P.SaturationControlValve2_UpperSat
	  section.data(46).logicalSrcIdx = 45;
	  section.data(46).dtTransOffset = 63;
	
	  ;% pilote_maquette_niveau_P.SaturationControlValve2_LowerSat
	  section.data(47).logicalSrcIdx = 46;
	  section.data(47).dtTransOffset = 64;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P1_Size_e
	  section.data(48).logicalSrcIdx = 47;
	  section.data(48).dtTransOffset = 65;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P1_l
	  section.data(49).logicalSrcIdx = 48;
	  section.data(49).dtTransOffset = 67;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P2_Size_d
	  section.data(50).logicalSrcIdx = 49;
	  section.data(50).dtTransOffset = 68;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P2_n
	  section.data(51).logicalSrcIdx = 50;
	  section.data(51).dtTransOffset = 70;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P3_Size_g
	  section.data(52).logicalSrcIdx = 51;
	  section.data(52).dtTransOffset = 71;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P3_in
	  section.data(53).logicalSrcIdx = 52;
	  section.data(53).dtTransOffset = 73;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P4_Size_o
	  section.data(54).logicalSrcIdx = 53;
	  section.data(54).dtTransOffset = 74;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P4_m
	  section.data(55).logicalSrcIdx = 54;
	  section.data(55).dtTransOffset = 76;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P5_Size_g
	  section.data(56).logicalSrcIdx = 55;
	  section.data(56).dtTransOffset = 77;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P5_l
	  section.data(57).logicalSrcIdx = 56;
	  section.data(57).dtTransOffset = 79;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P6_Size_c
	  section.data(58).logicalSrcIdx = 57;
	  section.data(58).dtTransOffset = 80;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P6_c
	  section.data(59).logicalSrcIdx = 58;
	  section.data(59).dtTransOffset = 82;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P7_Size_c
	  section.data(60).logicalSrcIdx = 59;
	  section.data(60).dtTransOffset = 83;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P7_f
	  section.data(61).logicalSrcIdx = 60;
	  section.data(61).dtTransOffset = 85;
	
	  ;% pilote_maquette_niveau_P.Valve3_Value
	  section.data(62).logicalSrcIdx = 61;
	  section.data(62).dtTransOffset = 86;
	
	  ;% pilote_maquette_niveau_P.SaturationControlValve3_UpperSat
	  section.data(63).logicalSrcIdx = 62;
	  section.data(63).dtTransOffset = 87;
	
	  ;% pilote_maquette_niveau_P.SaturationControlValve3_LowerSat
	  section.data(64).logicalSrcIdx = 63;
	  section.data(64).dtTransOffset = 88;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P1_Size_p
	  section.data(65).logicalSrcIdx = 64;
	  section.data(65).dtTransOffset = 89;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P1_o
	  section.data(66).logicalSrcIdx = 65;
	  section.data(66).dtTransOffset = 91;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P2_Size_f
	  section.data(67).logicalSrcIdx = 66;
	  section.data(67).dtTransOffset = 92;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P2_f
	  section.data(68).logicalSrcIdx = 67;
	  section.data(68).dtTransOffset = 94;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P3_Size_d
	  section.data(69).logicalSrcIdx = 68;
	  section.data(69).dtTransOffset = 95;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P3_b
	  section.data(70).logicalSrcIdx = 69;
	  section.data(70).dtTransOffset = 97;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P4_Size_d
	  section.data(71).logicalSrcIdx = 70;
	  section.data(71).dtTransOffset = 98;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P4_o
	  section.data(72).logicalSrcIdx = 71;
	  section.data(72).dtTransOffset = 100;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P5_Size_m
	  section.data(73).logicalSrcIdx = 72;
	  section.data(73).dtTransOffset = 101;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P5_f
	  section.data(74).logicalSrcIdx = 73;
	  section.data(74).dtTransOffset = 103;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P6_Size_f
	  section.data(75).logicalSrcIdx = 74;
	  section.data(75).dtTransOffset = 104;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P6_e
	  section.data(76).logicalSrcIdx = 75;
	  section.data(76).dtTransOffset = 106;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P7_Size_a
	  section.data(77).logicalSrcIdx = 76;
	  section.data(77).dtTransOffset = 107;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P7_n
	  section.data(78).logicalSrcIdx = 77;
	  section.data(78).dtTransOffset = 109;
	
	  ;% pilote_maquette_niveau_P.Valve4_Value_f
	  section.data(79).logicalSrcIdx = 78;
	  section.data(79).dtTransOffset = 110;
	
	  ;% pilote_maquette_niveau_P.SaturationControlValve4_UpperSat
	  section.data(80).logicalSrcIdx = 79;
	  section.data(80).dtTransOffset = 111;
	
	  ;% pilote_maquette_niveau_P.SaturationControlValve4_LowerSat
	  section.data(81).logicalSrcIdx = 80;
	  section.data(81).dtTransOffset = 112;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P1_Size_l
	  section.data(82).logicalSrcIdx = 81;
	  section.data(82).dtTransOffset = 113;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P1_oz
	  section.data(83).logicalSrcIdx = 82;
	  section.data(83).dtTransOffset = 115;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P2_Size_p
	  section.data(84).logicalSrcIdx = 83;
	  section.data(84).dtTransOffset = 116;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P2_j
	  section.data(85).logicalSrcIdx = 84;
	  section.data(85).dtTransOffset = 118;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P3_Size_e
	  section.data(86).logicalSrcIdx = 85;
	  section.data(86).dtTransOffset = 119;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P3_a
	  section.data(87).logicalSrcIdx = 86;
	  section.data(87).dtTransOffset = 121;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P4_Size_b
	  section.data(88).logicalSrcIdx = 87;
	  section.data(88).dtTransOffset = 122;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P4_f
	  section.data(89).logicalSrcIdx = 88;
	  section.data(89).dtTransOffset = 124;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P5_Size_a
	  section.data(90).logicalSrcIdx = 89;
	  section.data(90).dtTransOffset = 125;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P5_i
	  section.data(91).logicalSrcIdx = 90;
	  section.data(91).dtTransOffset = 127;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P6_Size_ee
	  section.data(92).logicalSrcIdx = 91;
	  section.data(92).dtTransOffset = 128;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P6_k
	  section.data(93).logicalSrcIdx = 92;
	  section.data(93).dtTransOffset = 130;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P7_Size_g
	  section.data(94).logicalSrcIdx = 93;
	  section.data(94).dtTransOffset = 131;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P7_fq
	  section.data(95).logicalSrcIdx = 94;
	  section.data(95).dtTransOffset = 133;
	
	  ;% pilote_maquette_niveau_P.Valve5_Value
	  section.data(96).logicalSrcIdx = 95;
	  section.data(96).dtTransOffset = 134;
	
	  ;% pilote_maquette_niveau_P.SaturationControlValve5_UpperSat
	  section.data(97).logicalSrcIdx = 96;
	  section.data(97).dtTransOffset = 135;
	
	  ;% pilote_maquette_niveau_P.SaturationControlValve5_LowerSat
	  section.data(98).logicalSrcIdx = 97;
	  section.data(98).dtTransOffset = 136;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P1_Size_h
	  section.data(99).logicalSrcIdx = 98;
	  section.data(99).dtTransOffset = 137;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P1_d
	  section.data(100).logicalSrcIdx = 99;
	  section.data(100).dtTransOffset = 139;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P2_Size_i
	  section.data(101).logicalSrcIdx = 100;
	  section.data(101).dtTransOffset = 140;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P2_c
	  section.data(102).logicalSrcIdx = 101;
	  section.data(102).dtTransOffset = 142;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P3_Size_l
	  section.data(103).logicalSrcIdx = 102;
	  section.data(103).dtTransOffset = 143;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P3_bs
	  section.data(104).logicalSrcIdx = 103;
	  section.data(104).dtTransOffset = 145;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P4_Size_dn
	  section.data(105).logicalSrcIdx = 104;
	  section.data(105).dtTransOffset = 146;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P4_n
	  section.data(106).logicalSrcIdx = 105;
	  section.data(106).dtTransOffset = 148;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P5_Size_an
	  section.data(107).logicalSrcIdx = 106;
	  section.data(107).dtTransOffset = 149;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P5_j
	  section.data(108).logicalSrcIdx = 107;
	  section.data(108).dtTransOffset = 151;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P6_Size_d
	  section.data(109).logicalSrcIdx = 108;
	  section.data(109).dtTransOffset = 152;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P6_j
	  section.data(110).logicalSrcIdx = 109;
	  section.data(110).dtTransOffset = 154;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P7_Size_n
	  section.data(111).logicalSrcIdx = 110;
	  section.data(111).dtTransOffset = 155;
	
	  ;% pilote_maquette_niveau_P.RTDACPCIPWM_P7_m
	  section.data(112).logicalSrcIdx = 111;
	  section.data(112).dtTransOffset = 157;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(1) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (parameter)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    paramMap.nTotData = nTotData;
    


  ;%**************************
  ;% Create Block Output Map *
  ;%**************************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 1;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc sigMap
    ;%
    sigMap.nSections           = nTotSects;
    sigMap.sectIdxOffset       = sectIdxOffset;
      sigMap.sections(nTotSects) = dumSection; %prealloc
    sigMap.nTotData            = -1;
    
    ;%
    ;% Auto data (pilote_maquette_niveau_B)
    ;%
      section.nData     = 9;
      section.data(9)  = dumData; %prealloc
      
	  ;% pilote_maquette_niveau_B.RTDACFrequencies
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% pilote_maquette_niveau_B.Fcn
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 5;
	
	  ;% pilote_maquette_niveau_B.RTDACSafetyAlert
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 6;
	
	  ;% pilote_maquette_niveau_B.SaturationControlPump
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 7;
	
	  ;% pilote_maquette_niveau_B.SaturationControlValve1
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 8;
	
	  ;% pilote_maquette_niveau_B.SaturationControlValve2
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 9;
	
	  ;% pilote_maquette_niveau_B.SaturationControlValve3
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 10;
	
	  ;% pilote_maquette_niveau_B.SaturationControlValve4
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 11;
	
	  ;% pilote_maquette_niveau_B.SaturationControlValve5
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 12;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(1) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (signal)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    sigMap.nTotData = nTotData;
    


  ;%*******************
  ;% Create DWork Map *
  ;%*******************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 1;
    sectIdxOffset = 1;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc dworkMap
    ;%
    dworkMap.nSections           = nTotSects;
    dworkMap.sectIdxOffset       = sectIdxOffset;
      dworkMap.sections(nTotSects) = dumSection; %prealloc
    dworkMap.nTotData            = -1;
    
    ;%
    ;% Auto data (pilote_maquette_niveau_DWork)
    ;%
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% pilote_maquette_niveau_DWork.Scope_PWORK.LoggedData
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(1) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (dwork)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    dworkMap.nTotData = nTotData;
    


  ;%
  ;% Add individual maps to base struct.
  ;%

  targMap.paramMap  = paramMap;    
  targMap.signalMap = sigMap;
  targMap.dworkMap  = dworkMap;
  
  ;%
  ;% Add checksums to base struct.
  ;%


  targMap.checksum0 = 912174894;
  targMap.checksum1 = 2254902532;
  targMap.checksum2 = 901182678;
  targMap.checksum3 = 3310349294;

