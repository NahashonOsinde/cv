/*
 *  rtmodel.h:
 *
 * Code generation for model "pilote_maquette_niveau".
 *
 * Model version              : 1.205
 * Simulink Coder version : 8.2 (R2012a) 29-Dec-2011
 * C source code generated on : Fri Nov 20 15:52:56 2020
 *
 * Target selection: rtwin.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#ifndef RTW_HEADER_rtmodel_h_
#define RTW_HEADER_rtmodel_h_

/*
 *  Includes the appropriate headers when we are using rtModel
 */
#include "pilote_maquette_niveau.h"
#define GRTINTERFACE                   1
#define ONESTEPFCN                     0
#endif                                 /* RTW_HEADER_rtmodel_h_ */
